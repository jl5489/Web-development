﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace labexw2
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string[] characterArray = new string[] {"Unknown Challenger", "Code thinker", "Friendly", "Responsible", "Math Lover", "Talkative", "Knowledge Seeker", "Humble"};
            bltCharacter.DataSource = characterArray;
            bltCharacter.DataBind();

            string[] eduArray = new string[] { "Primary: Graduated UPSR from SJK (C) Ming Chih", "Secondary: Gratuated SPM and UEC from Foon Yew High School Kulai", "Tertiary: Studying Bachelor of Computer Science, major in Software Engineering at Inti International University." };
            bltEdu.DataSource = eduArray;
            bltEdu.DataBind();

            string[] skillsArray = new string[] { "Public Relation", "Operation Management", "Team Leadership", "Communication", "Manpower Handling", "Scripting", "Sales & Marketing Alignment", "Props Decorating Idea", "Programming (C++, Java, HTML)" };
            bltSkills.DataSource = skillsArray;
            bltSkills.DataBind();

            string[] ISSTArray = new string[] { "Joined ISST since the first semester in university (June 2022)", "ISST, a corporate style management organization which assist counselors from Inti sales department to organize school activities", "Owen tends to learn more about leadership and management skills through the working environment that ISST provide in order to get prepared for his future career pathway" };
            bltISST.DataSource = ISSTArray;
            bltISST.DataBind();

            if(rblCSEC.SelectedIndex == 0)
            {
                imgshow.ImageUrl = "~/images/rfflogoclean.png";
                lblPos.Text = "Leader of Sales and Sponsorship";
                lblDesc.Text = "Run For Fun 2023 is a 8 km charity run organised by Chinese Independent School Alumni (CISA). As the leader of Sales and Sponsorship, \r\n            Owen had work alongside with his teammates to find potential event sponsorships and stall vendors. Besides, they also earned sufficient budget by selling food & beverages.\r\n            Throughout the commitment of the event, Owen has learned the techniques of sales and marketing alignment and enhance his personal communication skills.";
            }

            else if(rblCSEC.SelectedIndex == 1)
            {
                imgshow.ImageUrl = "~/images/csflogoclean2.png";
                lblPos.Text = "Hall Master";
                lblDesc.Text = "Chinese Summer Festival 2023 is a vendor market event organised by Chinese Culture Society (CCS). As the event Hall Master,\r\n            Owen work alongside with his teammates by brainstorming and design creative props and decorations. Throughout the commitment of the event,\r\n            Owen has learned the basic knowledge of paintings and evaluate his idea to create beautiful decorations.";
            }

            else
            {
                imgshow.ImageUrl = "";
                lblPos.Text = "";
                lblDesc.Text = "";
            }

            if(ddlGender.SelectedIndex == 1)
            {
                lblGname.Text = "Mr." + txtFname.Text;
            }

            else if(ddlGender.SelectedIndex == 2)
            {
                lblGname.Text = "Ms." + txtFname.Text;
            }

            else
            {
                lblGname.Text = txtFname.Text + "&nbsp;" + txtLname.Text;
            }
        }

        protected void rdoMember_CheckedChanged(object sender, EventArgs e)
        {
            lblTimeline.Text = "June 2022 - December 2022";
            lblDescription.Text = "As a member of ISST, Owen started out his first ISST event which is Open Day, followed by Chan Wa Camp 2022 and I-discover 2022." +
                "Throughout the process, he learned how school events operate and the responsibility of a facilitator by guiding and ensuring the safety of his groupmates throughout the event";
        }

        protected void rdoPR_CheckedChanged(object sender, EventArgs e)
        {
            lblTimeline.Text = "January 2023 - May 2023";
            lblDescription.Text = "Owen further his learning process by joining Public Relation Department. Got the chance to learn how to manage the social media of ISST, video editing, scripting and also protect the reputation of ISST.";
        }

        protected void rdoOP_CheckedChanged(object sender, EventArgs e)
        {
            lblTimeline.Text = "June 2023 - Present";
            lblDescription.Text = "In order to learn different skills in ISST, Owen switch to Operation department. Got the chance to learn about operation management and manpower alignment as to ensure quality of school events.";
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            txtFname.Text = "";
            txtLname.Text = "";
            txtPhone.Text = "";
            txtEmail.Text = "";
            txtCompany.Text = "";
            txtPos.Text = "";
            txtComment.Text = "";
            cblSkills.ClearSelection();
            ddlGender.ClearSelection();
            ddlRate.ClearSelection();
        }

        protected void btnNext_Click(object sender, EventArgs e)
        {
            String select = "";
            foreach(ListItem top in cblSkills.Items)
            {
                if (top.Selected)
                    select += top.Value + "&nbsp;";
            }
            cblSkills.Text = select;

            lblConfirmation.Text = "Name: " + txtFname.Text + "&nbsp;" + txtLname.Text + "<br />Phone Number: " + txtPhone.Text + "<br />Email Address: " + txtEmail.Text + "<br />Company: " + txtCompany.Text + "<br />Position: " + txtPos.Text + "<br />Interested Skills of Owen: " + select + "<br />Comment: " + txtComment.Text + "<br />Webpage Rating: " + ddlRate.SelectedIndex.ToString() + " out of 5";
        }
    }
}