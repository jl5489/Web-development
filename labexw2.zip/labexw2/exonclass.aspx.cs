﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace labexw2
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
                for(int i = 10; i <= 80; i += 10)
                    ddlDiscount.Items.Add(i.ToString());
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            decimal price = decimal.Parse(TxtSalesPrice.Text);
            decimal discount = Convert.ToDecimal(ddlDiscount.SelectedValue);

            decimal discAmount = price * (discount / 100);
            lblDisAm.Text = Convert.ToString(discAmount);
            lblTotal.Text = Convert.ToString(price - discAmount);
        }
    }
}