﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace labexw2.Properties
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            lblDetails.Text = "Name: " + txtCusName.Text + "<br />" + "Address: " + txtAddress.Text + "<br />" + "City: " + txtCity.Text + "<br />" + "Postcode: " + txtPostcode.Text + "<br />" + "Email: " + txtEmail.Text + "<br />" + "Phone: " + txtPhone.Text + "<br />" + "Product: " + txtProName.Text + "<br />" + "Price: " + txtProPrice.Text + "<br />" + "Quantity: " + txtProQty.Text + "<br />" + "Expected Delivery: " + txtExDeliDate.Text;
        }
    }
}